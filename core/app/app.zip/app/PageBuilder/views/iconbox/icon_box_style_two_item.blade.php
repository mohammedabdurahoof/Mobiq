<div class="slick-item">
    <div class="single-feature-support-item">
        <div class="icon-wrap">
            <i class="{{ $button_icon }} icon"></i>
        </div>
        <div class="content">
            <h6 class="title">{{ $title }}</h6>
            <p class="info">{{ $description }}</p>
        </div>
    </div>
</div>