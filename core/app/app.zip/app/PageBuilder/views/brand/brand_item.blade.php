<div class="slick-item">
    <div class="single-brand-new">
        {!! $brand_image !!}
    </div>
</div>