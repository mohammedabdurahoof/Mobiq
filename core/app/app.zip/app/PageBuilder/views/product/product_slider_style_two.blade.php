<div class="new-design-area-wrapper index-02" data-padding-top="{{$padding_top}}" data-padding-bottom="{{$padding_bottom}}">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5">
                <div class="section-title-wrapper">
                    <h2 class="main-title">{{$section_title}}</h2>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row new-design-slider-main">
            {!! $output !!}
        </div>
    </div>
</div>